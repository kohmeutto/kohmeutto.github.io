+++
title = "(b) Pesudo-adjoint"
weight = 3
+++

---