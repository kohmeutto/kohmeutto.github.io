+++
title = "(b) M-normal"
weight = 1
+++

---