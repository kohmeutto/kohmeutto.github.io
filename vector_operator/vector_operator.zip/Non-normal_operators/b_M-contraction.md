+++
title = '(b) M-contraction'
weight = 5
+++

---
