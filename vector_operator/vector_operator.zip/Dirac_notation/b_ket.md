+++
title = "(b) Ket"
weight = 1
+++

---

### 1. 이산기저  (Discrete Basis)

원점에서 x=1, y=2 로 향하는 **벡터**를 표현할 때,

**(1) 유클리드 공간**

$$
\vec{a}=1\hat{u}_1+2\hat{u}_2,\quad
\hat{u}_1=[1 \ 0]^T,\quad \hat{u}_2=[0 \ 1]^T
$$

**(2) 힐버트 공간**

$$
|a\rangle=1|u_1\rangle+2|u_1\rangle,\quad
|u_1\rangle=[1 \ 0]^T,\quad |u_1\rangle=[0 \ 1]^T
$$

---

### 2. 연속 기저 (Continuous Basis)

함수 f(x)의 함수를 표현할 때,

**(1) 유클리드 공간**

함수는 무한한 원소를 가지므로, 유클리드 공간의 벡터가 아니다.

**(2) 힐버트 공간**

- f(x)를 분해하면, f는 이름표 이다. 이 이름표가 붙은 Ket |f⟩는 힐버트 공간에 존재하는, 기저에 무관한 추상적인 상태 벡터 그 자체를 의미한다.
- f(x)는 **x상태** 에서의 f의 값이다. 따라서, 아래와 같이 표현할 수 있다.

$$
|f\rangle = \int dx f(x) |x\rangle
$$

---

### 3. 스칼라 곱의 표현

힐버트 공간 상태 벡터를 $|\psi\rangle$ 라 하고, $a$ 를 임의의 복소수 스칼라($a \in \mathbb{C}$)라고 하자. 관습적으로 아래와 같이 표현할 수 있다.

$$
a|\psi\rangle=|a\psi\rangle 
$$

ket 안에는 이름(문자, 숫자, 그림 등등) 이 들어간다. $a\psi$ 는 $a|\psi\rangle$ 의 결과에 대한 이름이다.
